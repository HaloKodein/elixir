import axios from 'axios'

export namespace Api {
  interface AuthorizationResponse {
    access_token: string
    refresh_token: string
    user: User
  }

  interface User {
    id: string
  }

  const headers = {
    Authorization:
      'Bot 369f857b18024f2eab53418aae51d8968b823bb3962825f57251727dc22354d1',
  }

  export async function requestAuthorization(data: unknown) {
    try {
      const response = await axios.post(
        'https://api.elixir-cheats.net/user/auth',
        data,
        {
          headers,
        },
      )

      if (response.status !== 200) return undefined

      return response.data.data as AuthorizationResponse
    } catch (error) {
      console.error(error)
      return undefined
    }
  }
}
