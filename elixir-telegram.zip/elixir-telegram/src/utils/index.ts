export namespace Utils {
  export function buildURL(access: string, refresh: string, id: string) {
    let url = 'https://elixir-cheats.net/auth#'

    url += 'target=telegram'
    url += `&access_token=${access}`
    url += `&refresh_token=${refresh}`
    url += `&user_id=${id}`

    return url
  }
}
