export interface ICommand {
  command: string
  description: string
}

export enum CommandDecorators {
  Login = 'login',
  AddFunds = 'add_funds',
  Authorize = 'authorize',
}
