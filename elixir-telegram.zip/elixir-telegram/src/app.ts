import { Markup, Telegraf } from 'telegraf'
import { Api } from './api'
import { CommandDecorators, type ICommand } from './types/Command'
import { Utils } from './utils'

const token = process.env.TOKEN as string

const client = new Telegraf(token)

const commands: ICommand[] = [
  { command: '/start', description: 'Starts the bot' },
  { command: '/login', description: 'Login to our site' },
]

client.telegram.setMyCommands(commands)

client.start(async (ctx) => {
  const start_message = `
    Welcome!

    You can use the command /login to log in to our website

    Or the buttons bellow.
  `.trim()

  await ctx.reply(
    start_message,
    Markup.inlineKeyboard([
      Markup.button.callback('Login', CommandDecorators.Login),
    ]),
  )
})

client.action(CommandDecorators.Login, async (ctx) => {
  await ctx.answerCbQuery()

  await ctx.reply(
    'Do you authorize login to our website?',
    Markup.inlineKeyboard([
      Markup.button.callback('Authorize', CommandDecorators.Authorize),
    ]),
  )
})

client.action(CommandDecorators.Authorize, async (ctx) => {
  await ctx.answerCbQuery()

  const data = {
    from: 'telegram',
    raw_id: ctx.from.id.toString(),
    username: ctx.from.username,
    avatar_url: '',
  }

  const authorization = await Api.requestAuthorization(data)

  if (!authorization) return

  const login = Utils.buildURL(
    authorization?.access_token,
    authorization?.refresh_token,
    authorization?.user.id,
  )

  await ctx.reply(
    'You can log in to our website by clicking the button below.',
    Markup.inlineKeyboard([
      Markup.button.url(
        'Login',
        Utils.buildURL(
          authorization?.access_token,
          authorization?.refresh_token,
          authorization?.user.id,
        ),
      ),
    ]),
  )
})

client.action(CommandDecorators.AddFunds, async (ctx) => {
  await ctx.reply('Which recharge option do you want?')
})

client.command(CommandDecorators.Login, async (ctx) => {
  await ctx.reply(
    'Do you authorize login to our website?\n (You need to configure your username (@) in settings).',
    Markup.inlineKeyboard([
      Markup.button.callback('Authorize', CommandDecorators.Authorize),
    ]),
  )
})

client.launch(() => {
  console.log('Client launched.')
})

process.once('SIGINT', () => client.stop('SIGINT'))
process.once('SIGTERM', () => client.stop('SIGTERM'))
