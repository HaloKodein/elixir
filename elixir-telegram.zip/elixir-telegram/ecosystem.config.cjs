module.exports = {
  apps: [
    {
      name: "elixir-telegram-bot",
      script: "bun",
      args: "--env-file .env ./src/app.ts",
      interpreter: "none",
      max_restarts: 10,
      restart_delay: 5000
    },
  ],
};